# Use these commands to generate the LAMMPS input script and data file
# (and other auxilliary files):
moltemplate.sh system.lt

# This will generate various files with names ending in *.in* and *.data. 

